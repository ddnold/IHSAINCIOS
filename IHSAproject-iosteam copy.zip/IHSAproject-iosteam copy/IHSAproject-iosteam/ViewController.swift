//
//  ViewController.swift
//  IHSAproject-iosteam
//
//  Created by student on 1/24/23.
//

import UIKit

class ViewController: UIViewController {
    
    //ihsalabel
    @IBOutlet weak var ihsaImg: UIImageView!
    
    //login label
    @IBOutlet weak var loginLabel: UILabel!
    
    //password label
    @IBOutlet weak var passLabel: UILabel!
    
    //User enters their username, and stored here
    @IBOutlet weak var userName: UITextField!
    
    //User enters their password and stored here
    @IBOutlet weak var userPass: UITextField!
    
    //Label display on correct or incorrect login
    @IBOutlet weak var validationLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func submitButton(_ sender: UIButton) {
        //store user and pass as text
        var user = userName.text!
        var pass = userPass.text!
        
        if(user != "" && pass != ""){
                validationLabel.text = "Welcome \(user)! 🐎"
        }
    }
    
    }
    
    
    



